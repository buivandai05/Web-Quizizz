import { Children } from "react";
import PrivateRoutes from "../component/PrivateRoutes";
import LayoutDefautl from "../layout/LayoutDefault";
import Home from "../page/Home";
import Login from "../Page/Login";
import Register from "../Page/Register";
import Answers from "../Page/Answers";
import Quiz from "../Page/Quiz";
import Result from "../Page/Result";
import Topic from "../Page/Topic";

export const Routes = [
    {
        path: "/",
        element: <LayoutDefautl />,
        children: [
            {
                path: "/",
                element: <Home />
            },

            {
                path: "Login",
                element: <Login />

            },
            {
                path: "Register",
                element: <Register />
            },
            {
                element: <PrivateRoutes />,
                children: [
                    {
                        path: "Answers",
                        element: <Answers />
                    },

                    {
                        path: "Quiz",
                        element: <Quiz />
                    },
                    {
                    path:"Result",
                    element:<Result/>
                    },

                    {
                    path:"Topic",
                    element:<Topic/>
                    },
                    

                ]
            }
        ]
    }
]