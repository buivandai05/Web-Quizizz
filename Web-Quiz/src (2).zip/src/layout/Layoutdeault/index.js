
import { Link, NavLink, Outlet } from "react-router-dom";
import "./layoutdefaut.scss";
import Home from "../../page/Home";

function LayoutDefautl() {
    return (
        <>
            <div className="layout_defautl">
                <header className="layout_header">
                    <div className="layout_logo">logo</div>
                    <div className="layout_menu">
                        <ul>
                            <li>
                                <NavLink to="/">Home</NavLink>
                            </li>
                            <li>
                                <NavLink to="/Topic">Topic</NavLink>
                            </li>
                            <li>
                                <NavLink to="/Answer">Answer</NavLink>
                            </li>
                        </ul>
                    </div>
                </header>
                <main className="layout_main">
                    <Outlet />
                </main>
                <footer className="layout_footer">
                    xin chao moi nguoi by buivandai
                </footer>
            </div>
        </>
    )
}
export default LayoutDefautl;