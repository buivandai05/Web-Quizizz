import { useRoutes } from "react-router-dom";
import routesConfig from "../routes"; // import file config của bạn

function Allroute() {
    const elements = useRoutes(routesConfig);
    return elements;
}

export default Allroute;
