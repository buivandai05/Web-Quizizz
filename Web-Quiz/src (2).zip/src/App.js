import Allroute from "../src/component/Allroutes/index.js";
import './App.css';

function App() {
  return (
    <>
      <Allroute/>
    </>
  );
}

export default App;
