function Quiz(){
    return(
        <>
        Quiz
        </>
    )
}
export default Quiz;
