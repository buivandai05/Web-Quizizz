function Result(){
    return(
        <>
        Result
        </>
    )
}
export default Result;
