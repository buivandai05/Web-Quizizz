function Register(){
    return(
        <>
        Register
        </>
    )
}
export default Register;
