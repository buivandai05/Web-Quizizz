function Answers(){
    return(
        <>
        Answers
        </>
    )
}
export default Answers;
